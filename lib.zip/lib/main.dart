import 'package:flutter/material.dart';
import 'package:notilist/pages/login_page.dart';
import 'package:notilist/pages/add_note_page.dart';
import 'package:notilist/pages/profile_page.dart';
import 'package:notilist/pages/register_page%20copy.dart';
import 'package:notilist/pages/add_task_page.dart';
import 'package:notilist/pages/my_note_page.dart';
import 'package:notilist/pages/my_to_do.dart';
import 'package:notilist/pages/my_calendar.dart';

void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(scaffoldBackgroundColor: const Color(0xfffff9f2)),
      // home: const LoginPage(),
      // home: const RegisterPage(),
      // home: const ProfileP age(),
      // home: NoteEditPage(),
      // home: NoteAddPage(),
       // home: TaskAddPage(),
      // home: Note(),
      // home: Todo(),
      // home: Ca()
      
    );
  }

 }


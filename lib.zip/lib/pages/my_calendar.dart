import 'package:flutter/material.dart';

class Ca extends StatefulWidget {
  const Ca({Key? key}) : super(key: key);

  @override
  _TodoState createState() => _TodoState();
}

class _TodoState extends State<Ca> {
 final List<Color> colorList = [
    Color(0xffffffff),
    Color(0xffffaeae),
    Color(0xffffd392),
    Color(0xffb7f6ff),
    Color(0xffcdafff),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Calendar",
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Color.fromARGB(255, 176, 230, 255),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.search,
              color: Colors.black87,
            ),
            tooltip: 'Search',
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(
              Icons.menu,
              color: Colors.black87,
            ),
            tooltip: 'Menu',
            onPressed: () {},
          ),
        ],
      ),
    );
  }
}